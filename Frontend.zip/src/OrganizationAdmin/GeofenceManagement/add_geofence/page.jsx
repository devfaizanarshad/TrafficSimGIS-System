"use client";

import React, { useState } from "react";
import {
  MapContainer,
  TileLayer,
  Polygon,
  useMapEvents,
} from "react-leaflet";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const CreateGeofence = () => {
  const [name, setName] = useState("");
  const [points, setPoints] = useState([]);
  const [loading, setLoading] = useState(false);

  // Handle click on the map
  const handleMapClick = (e) => {
    const { lat, lng } = e.latlng;
    setPoints((prevPoints) => [
      ...prevPoints,
      { latitude: lat, longitude: lng },
    ]);
  };

  // Remove a point from the list
  const handleRemovePoint = (index) => {
    setPoints((prevPoints) => prevPoints.filter((_, i) => i !== index));
  };

  // Handle submission of geofence creation
  const handleSubmit = async () => {
    if (!name.trim()) {
      toast.error("Please provide a Geofence name.");
      return;
    }

    if (points.length < 3) {
      toast.error("At least 3 points are required to create a geofence.");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch(
        "http://localhost:3000/api/admin/create-geofence",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, boundary: points }),
        }
      );

      if (response.ok) {
        toast.success("✅ Geofence created successfully!");
        // Reset form after successful submission
        setName("");
        setPoints([]);
      } else {
        toast.error("❌ Failed to create geofence. Try again!");
      }
    } catch (error) {
      console.error("Error creating geofence:", error);
      toast.error("🚨 Server error. Please try later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen p-8 bg-gray-100">
      <div className="relative w-full max-w-5xl p-8 bg-white rounded-lg shadow-lg">
        {/* Page Title */}
        <h2 className="mb-6 text-3xl font-bold text-gray-800">
          Create Geofence
        </h2>

        {/* Geofence Name Input */}
        <div className="mb-6">
          <label className="block mb-2 text-sm font-medium text-gray-700">
            Geofence Name
          </label>
          <input
            type="text"
            placeholder="Enter Geofence Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1E90FF] focus:outline-none"
          />
        </div>

        {/* Map Section */}
        <div className="h-[400px] mb-6">
          <MapContainer
            center={[33.6844, 73.0479]}
            zoom={13}
            className="w-full h-full rounded-lg"
          >
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution="© OpenStreetMap"
            />
            <MapClickHandler onClick={handleMapClick} />

            {/* Polygon */}
            {points.length > 0 && (
              <Polygon
                positions={points.map((p) => [p.latitude, p.longitude])}
                pathOptions={{ color: "#1E90FF" }}
              />
            )}
          </MapContainer>
        </div>

        {/* Boundary Points List */}
        <div className="mb-6">
          <h3 className="mb-2 text-lg font-semibold text-gray-700">
            Boundary Points
          </h3>
          {points.length === 0 ? (
            <p className="text-sm text-gray-500">
              Click on the map to add points.
            </p>
          ) : (
            <ul className="divide-y divide-gray-200 max-h-[200px] overflow-y-auto">
              {points.map((point, index) => (
                <li
                  key={index}
                  className="flex justify-between py-2 text-sm text-gray-600"
                >
                  <span>
                    Lat: {point.latitude.toFixed(4)}, Lng:{" "}
                    {point.longitude.toFixed(4)}
                  </span>
                  <button
                    onClick={() => handleRemovePoint(index)}
                    className="text-xs text-red-500 hover:text-red-700"
                  >
                    Remove
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Submit Button */}
        <div className="flex justify-end">
          <button
            onClick={handleSubmit}
            disabled={loading}
            className={`px-6 py-3 rounded-md text-white font-medium transition duration-300 ${
              loading
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-[#FF8A8A] hover:bg-[#fb5f5f]"
            }`}
          >
            {loading ? "Creating..." : "Create Geofence"}
          </button>
        </div>

        {/* Toast Notifications */}
        <ToastContainer
          position="top-center"
          autoClose={3000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
          theme="colored"
        />
      </div>
    </div>
  );
};

const MapClickHandler = ({ onClick }) => {
  useMapEvents({
    click: onClick,
  });
  return null;
};

export default CreateGeofence;
