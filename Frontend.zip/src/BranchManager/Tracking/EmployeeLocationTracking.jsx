import React, { useState, useEffect } from "react";
import L from "leaflet";
import { MapContainer, TileLayer, Marker, Popup, Polygon } from "react-leaflet";
import Select from "react-select";
import "leaflet/dist/leaflet.css";
import axios from "axios";

const EmployeeTracking = () => {
  const [employees, setEmployees] = useState([]);
  const [selectedEmployees, setSelectedEmployees] = useState([]);
  const [employeeLocations, setEmployeeLocations] = useState({});
  const [employeeGeofences, setEmployeeGeofences] = useState({});
  const managerId = 1;

  // Fetch employees under the manager
  useEffect(() => {
    axios
      .get(`http://localhost:3000/api/manager/${managerId}/employees`)
      .then((res) => {
        setEmployees(res.data.employees);
        setSelectedEmployees([{ value: "all", label: "All Employees" }]); // Default to all
      })
      .catch((err) => console.error("Error fetching employees:", err));
  }, [managerId]);

  // Fetch employee locations
  useEffect(() => {
    const fetchLocations = async () => {
      let locations = {};
      if (selectedEmployees.some((e) => e.value === "all")) {
        // If "All" is selected, fetch all employees' locations
        await Promise.all(
          employees.map(async (emp) => {
            try {
              const res = await axios.get(
                `http://localhost:3000/api/manager/employee/${emp.employee_id}/location`
              );
              locations[emp.employee_id] = res.data;
            } catch (err) {
              console.error(`Error fetching location for ${emp.employee_id}:`, err);
            }
          })
        );
      } else {
        // Fetch only selected employees' locations
        await Promise.all(
          selectedEmployees.map(async (emp) => {
            try {
              const res = await axios.get(
                `http://localhost:3000/api/manager/employee/${emp.value}/location`
              );
              locations[emp.value] = res.data;
            } catch (err) {
              console.error(`Error fetching location for ${emp.value}:`, err);
            }
          })
        );
      }
      setEmployeeLocations(locations);
    };

    if (selectedEmployees.length > 0) {
      fetchLocations();
    } else {
      setEmployeeLocations({});
    }
  }, [selectedEmployees, employees]);

  // Fetch geofences for each employee
  useEffect(() => {
    const fetchGeofences = async () => {
      let geofences = {};
      if (selectedEmployees.some((e) => e.value === "all")) {
        // If "All" is selected, fetch all employees' geofences
        await Promise.all(
          employees.map(async (emp) => {
            try {
              const res = await axios.get(
                `http://localhost:3000/api/employee/my-geofences/${emp.employee_id}`
              );
              geofences[emp.employee_id] = res.data.geofences;
            } catch (err) {
              console.error(`Error fetching geofences for ${emp.employee_id}:`, err);
            }
          })
        );
      } else {
        // Fetch geofences for only selected employees
        await Promise.all(
          selectedEmployees.map(async (emp) => {
            try {
              const res = await axios.get(
                `http://localhost:3000/api/employee/my-geofences/${emp.value}`
              );
              geofences[emp.value] = res.data.geofences;
            } catch (err) {
              console.error(`Error fetching geofences for ${emp.value}:`, err);
            }
          })
        );
      }
      setEmployeeGeofences(geofences);
    };

    if (selectedEmployees.length > 0) {
      fetchGeofences();
    } else {
      setEmployeeGeofences({});
    }
  }, [selectedEmployees, employees]);

  // Custom styles for select dropdown
  const selectStyles = {
    control: (styles) => ({
      ...styles,
      borderRadius: "8px",
      padding: "5px",
      borderColor: "#E5E7EB",
      boxShadow: "none",
      ":hover": { borderColor: "#007bff" },
    }),
    option: (styles, { isSelected }) => ({
      ...styles,
      backgroundColor: isSelected ? "#007bff" : "#fff",
      color: isSelected ? "#fff" : "#333",
      ":hover": { backgroundColor: "#f1f1f1" },
    }),
  };

  // Handle click on a geofence polygon to show geofence info in a popup
  const handleGeofenceClick = (event, geofenceName, employeeName) => {
    const popupContent = `
      <div>
        <strong>Geofence Name:</strong> ${geofenceName} <br/>
        <strong>Assigned to Employee:</strong> ${employeeName}
      </div>
    `;

    const popup = L.popup()
      .setLatLng(event.latlng) // Position the popup at the click location
      .setContent(popupContent)
      .openOn(event.target._map);
  };

  return (
    <div className="flex flex-col gap-4 p-4">
      {/* Employee Selection Dropdown */}
      <div className="w-full sm:w-[300px] z-50">
        <Select
          options={[
            { value: "all", label: "All Employees" },
            ...employees.map((e) => ({
              value: e.employee_id,
              label: `${e.first_name} ${e.last_name}`,
            })),
          ]}
          value={selectedEmployees}
          onChange={(selected) =>
            setSelectedEmployees(selected.length ? selected : [{ value: "all", label: "All Employees" }])
          }
          isMulti
          isClearable={false}
          placeholder="Select Employees"
          styles={selectStyles}
        />
      </div>

      {/* Map Display */}
      <MapContainer center={[33.6844, 73.0479]} zoom={12} style={{ height: "500px", width: "100%" }}>
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />

        {Object.keys(employeeLocations).map((empId) => {
          const emp = employees.find((e) => e.employee_id === parseInt(empId));
          const location = employeeLocations[empId]?.employeeLocations;

          if (!location || location.latitude === undefined || location.longitude === undefined) {
            console.warn(`Skipping employee ${empId} due to missing location data.`);
            return null;
          }

          return (
            <>
              <Marker
                key={`marker-${empId}`}
                position={[location.latitude, location.longitude]}
                icon={L.icon({
                  iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
                  iconSize: [25, 41],
                  iconAnchor: [12, 41],
                  popupAnchor: [1, -34],
                })}
              >
                <Popup>
                  <b>{emp ? `${emp.first_name} ${emp.last_name}` : "Unknown Employee"}</b>
                  <br />
                  Location: ({location.latitude}, {location.longitude})
                </Popup>
              </Marker>

              {/* Display geofence boundary */}
              {employeeGeofences[empId]?.[0]?.geofence_boundary && (
                <Polygon
                  key={`polygon-${empId}`}
                  positions={employeeGeofences[empId][0].geofence_boundary.map((point) => [
                    point.latitude,
                    point.longitude,
                  ])}
                  color="blue"
                  fillColor="rgba(0, 0, 255, 0.2)"
                  weight={2}
                  eventHandlers={{
                    click: (event) =>
                      handleGeofenceClick(event, employeeGeofences[empId][0].geofence_name, `${emp.first_name} ${emp.last_name}`),
                  }}
                />
              )}
            </>
          );
        })}
      </MapContainer>
    </div>
  );
};

export default EmployeeTracking;
