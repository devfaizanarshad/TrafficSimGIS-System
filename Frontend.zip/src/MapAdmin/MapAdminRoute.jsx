import React, { useState, useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

const SleekRouteUI = () => {
  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const routeLayerRef = useRef(null);

  const [source, setSource] = useState("");
  const [destination, setDestination] = useState("");
  const [sourceCoords, setSourceCoords] = useState(null);
  const [destinationCoords, setDestinationCoords] = useState(null);
  const [instructions, setInstructions] = useState([]);

  // Custom SVG icons for markers
  const sourceSVG = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" height="30" width="30" style="cursor: pointer;">
      <path d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0z" fill="#4CAF50"></path>
      <path d="M192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z" fill="white"></path>
    </svg>`;

  const destinationSVG = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" height="30" width="30" style="cursor: pointer;">
      <path d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0z" fill="#E91E63"></path>
      <path d="M192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z" fill="white"></path>
    </svg>`;

  useEffect(() => {
    if (mapInstanceRef.current) return;

    const map = L.map(mapRef.current, { zoomControl: false }).setView([33.6844, 73.0479], 12);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "© OpenStreetMap contributors",
    }).addTo(map);

    L.control.zoom({ position: "topright" }).addTo(map);

    mapInstanceRef.current = map;
  }, []);

  const handleSearch = async (type) => {
    const query = type === "source" ? source : destination;
    if (!query) return;

    try {
      const res = await fetch(`http://localhost:3000/api/location/search-location?location=${query}`);
      const data = await res.json();

      if (data.length > 0) {
        const { lat, lon } = data[0];
        const coords = [parseFloat(lat), parseFloat(lon)];

        if (type === "source") {
          setSourceCoords(coords);
          placeMarker(coords, "Source", sourceSVG);
        } else {
          setDestinationCoords(coords);
          placeMarker(coords, "Destination", destinationSVG);
        }
      } else {
        alert("No location found.");
      }
    } catch (error) {
      console.error("Search error:", error);
    }
  };

  const placeMarker = (coords, label, svgMarkup) => {
    const map = mapInstanceRef.current;

    const customDivIcon = L.divIcon({
      html: svgMarkup,
      className: "",
      iconSize: [30, 30],
      iconAnchor: [15, 30],
    });

    L.marker(coords, { icon: customDivIcon })
      .addTo(map)
      .bindPopup(label)
      .openPopup();

    map.setView(coords, 13);
  };

  const handleFindRoute = async () => {
    if (!sourceCoords || !destinationCoords) {
      alert("Please select both Source and Destination.");
      return;
    }

    try {
      const url = `http://localhost:8989/route?point=${sourceCoords.join(",")}&point=${destinationCoords.join(",")}&type=json&profile=car`;
      const res = await fetch(url);
      const data = await res.json();

      console.log(data);
      

      if (data.paths && data.paths.length > 0) {
        const path = data.paths[0];
        const coords = decodePolyline(path.points);

        console.log(coords);

        const congestedPoints = await checkCongestion(coords);
        console.log("Congested Points:", congestedPoints);

        animateRoute(coords, congestedPoints);
        
        setInstructions(path.instructions || []);
      } else {
        alert("No route found.");
      }
    } catch (err) {
      console.error("Route error:", err);
    }
  };

const checkCongestion = async (coords) => {
  try {
    const response = await fetch('http://localhost:3000/api/location/check-congestion', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ graphhopper_coordinates: coords })   // sending points to your API
    });

    const data = await response.json();

    if (data.result && data.result.status === "Segment is Congested") {
      return data.result.matchedPoints;
    } else {
      return [];
    }
  } catch (error) {
    console.error('Congestion check error:', error);
    return [];
  }
};

  const decodePolyline = (encoded) => {
    let points = [];
    let index = 0, lat = 0, lng = 0;

    while (index < encoded.length) {
      let b, shift = 0, result = 0;
      do {
        b = encoded.charCodeAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      let dlat = (result & 1) ? ~(result >> 1) : result >> 1;
      lat += dlat;

      shift = 0;
      result = 0;
      do {
        b = encoded.charCodeAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      let dlng = (result & 1) ? ~(result >> 1) : result >> 1;
      lng += dlng;

      points.push([lat / 1e5, lng / 1e5]);
    }

    console.log(points);
    
    return points;
  };


  const animateRoute = (coords, congestedPoints = []) => {
    const map = mapInstanceRef.current;
  
    if (routeLayerRef.current) {
      map.removeLayer(routeLayerRef.current);
    }
  
    const isCongested = (lat, lon) => {
      return congestedPoints.some(p => 
        Math.abs(p.lat - lat) < 0.0005 && Math.abs(p.lon - lon) < 0.0005
      );
    };
  
    const segments = [];
  
    for (let i = 0; i < coords.length - 1; i++) {
      const start = coords[i];
      const end = coords[i + 1];
  
      const congested = isCongested(start[0], start[1]) || isCongested(end[0], end[1]);
  
      const segment = L.polyline([start, end], {
        color: congested ? 'red' : '#0077FF',  // 🔥 red for congestion, blue otherwise
        weight: 4,
        opacity: 0.8,
        lineJoin: 'round'
      }).addTo(map);
  
      segments.push(segment);
    }
  
    const group = L.featureGroup(segments);
    map.fitBounds(group.getBounds());
  
    routeLayerRef.current = group;
  };


  return (
    <div className="flex h-screen bg-white">
      {/* Left Panel */}
      <div className="flex flex-col justify-start p-6 border-r border-gray-200 rounded-lg shadow-md w-96 bg-white/30 backdrop-blur-md">
        <h2 className="mb-6 text-xl font-bold text-gray-800">Route Finder</h2>

        <div className="mb-4">
          <label className="block mb-1 text-sm text-gray-600">Source</label>
          <div className="flex">
            <input
              type="text"
              value={source}
              onChange={(e) => setSource(e.target.value)}
              className="flex-1 px-3 py-2 text-sm border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter source location"
            />
            <button
              onClick={() => handleSearch("source")}
              className="px-3 py-2 text-sm text-white bg-blue-500 rounded-r-md hover:bg-blue-600"
            >
              Go
            </button>
          </div>
        </div>

        <div className="mb-4">
          <label className="block mb-1 text-sm text-gray-600">Destination</label>
          <div className="flex">
            <input
              type="text"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              className="flex-1 px-3 py-2 text-sm border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter destination location"
            />
            <button
              onClick={() => handleSearch("destination")}
              className="px-3 py-2 text-sm text-white bg-pink-500 rounded-r-md hover:bg-pink-600"
            >
              Go
            </button>
          </div>
        </div>

        <button
          onClick={handleFindRoute}
          className="w-full py-2 mt-2 text-sm text-white transition-all rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 hover:opacity-90"
        >
          Find Route
        </button>

        {/* Instructions */}
        {/* <div className="flex-1 mt-6 overflow-auto">
          <h3 className="mb-2 text-sm font-semibold text-gray-700">Instructions</h3>
          <ul className="space-y-2 text-xs text-gray-600">
            {instructions.length > 0 ? (
              instructions.map((inst, idx) => (
                <li key={idx} className="p-2 border border-gray-100 rounded bg-gray-50">
                  {idx + 1}. {inst.text}
                </li>
              ))
            ) : (
              <li>No instructions available</li>
            )}
          </ul>
        </div> */}
      </div>

      {/* Map */}
      <div className="relative flex-1">
        <div ref={mapRef} className="absolute top-0 bottom-0 left-0 right-0 z-0" />
      </div>
    </div>
  );
};

export default SleekRouteUI;
