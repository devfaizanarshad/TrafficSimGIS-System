import React, { useEffect, useState } from "react";
import axios from "axios";
import { NavLink } from "react-router-dom";
import { FiPlus, FiEdit, FiSearch, FiEye, FiTrash2 } from "react-icons/fi";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Modal from "react-modal";



const UserDetails = ({ user, isOpen, onClose }) => {
  if (!user) return null;

  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={onClose}
      className="fixed inset-0 flex items-center justify-center p-6 bg-black bg-opacity-50"
      overlayClassName="fixed inset-0"
    >
      <div className="relative w-full max-w-lg p-6 bg-white rounded-lg shadow-lg">
        <button
          className="absolute text-gray-500 top-4 right-4 hover:text-gray-800"
          onClick={onClose}
        >
          <FiX size={24} />
        </button>
        <div className="flex items-center space-x-4">
          <div className="flex items-center justify-center w-16 h-16 text-xl text-gray-600 bg-gray-200 rounded-full">
            <FiUser size={32} />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-800">{user.username}</h2>
            <p className="text-gray-500">{user.role}</p>
          </div>
        </div>
        <div className="mt-6 space-y-4">
          <div className="flex items-center text-gray-700">
            <FiMail className="mr-2" /> {user.email}
          </div>
          <div className="flex items-center text-gray-700">
            <FiPhone className="mr-2" /> {user.phone || "N/A"}
          </div>
          <div className="flex items-center text-gray-700">
            <FiBriefcase className="mr-2" /> {user.role}
          </div>
          <div className="flex items-center text-gray-700">
            <FiMapPin className="mr-2" /> {user.city || "N/A"}
          </div>
          <div className="flex items-center text-gray-700">
            <FiCalendar className="mr-2" /> {new Date(user.created_at).toLocaleDateString()}
          </div>
        </div>
      </div>
    </Modal>
  );
};


const UserTable = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("");
  const [selectedUser, setSelectedUser] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    axios
      .get("http://localhost:3000/api/admin/list-users")
      .then((response) => {
        setUsers(response.data.users);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching users:", error);
        setError("Failed to fetch data.");
        setLoading(false);
      });
  }, []);

   // Delete user function
   const deleteUser = async (user) => {
    toast.info(
      <div>
        <p className="text-lg font-semibold">Are you sure?</p>
        <p className="text-sm text-gray-600">You are about to delete <b>{user.username}</b>.</p>
        <div className="flex justify-end mt-3 space-x-3">
          <button className="px-4 py-2 bg-gray-300 rounded-lg" onClick={toast.dismiss}>Cancel</button>
          <button
            className="px-4 py-2 text-white bg-red-500 rounded-lg"
            onClick={async () => {
              toast.dismiss();
              try {
                const response = await fetch(`http://localhost:3000/api/admin/deactivate-user/${user.user_id}`, {
                  method: "PATCH",
                });

                if (response.ok) {
                  setUsers(users.filter((u) => u.user_id !== user.user_id));
                  toast.success("User deleted successfully!", { autoClose: 2000 });
                } else {
                  toast.error("Failed to delete user.");
                }
              } catch (error) {
                console.error("Error deleting user:", error);
                toast.error("An error occurred while deleting the user.");
              }
            }}
          >
            Confirm
          </button>
        </div>
      </div>,
      { autoClose: false, closeOnClick: false, draggable: false }
    );
  };

  const filteredUsers = users.filter(
    (user) =>
      user.username.toLowerCase().includes(search.toLowerCase()) &&
      (filter ? user.role === filter : true)
  );

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div className="min-h-screen p-6 bg-white">
      <div className="flex flex-wrap items-center gap-3 mb-4">
        {/* Search Bar */}
        <div className="relative flex items-center w-full max-w-md">
          <FiSearch className="absolute text-gray-500 left-3" />
          <input
            type="text"
            placeholder="Search users..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-6 py-2 border border-gray-300 bg-white rounded-full shadow-sm focus:outline-none focus:ring-2 focus:ring-[#FF8A8A]"
          />
        </div>

        {/* Filter Dropdown */}
        <div className="flex items-center">
          <span className="mr-2 text-[#6B7280]">Filter by</span>
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="px-6 py-2 border border-gray-300 bg-white rounded-full text-[#6B7280] focus:outline-none focus:ring-2"
          >
            <option value="">All Roles</option>
            <option value="Employee">Employee</option>
            <option value="Manager">Manager</option>
            <option value="Admin">Admin</option>
          </select>
        </div>

{/* Add User Button */}
<NavLink
  to="/admin/create-user"
  className="flex items-center ml-15 gap-3 bg-[#FF8A8A] text-white px-6 py-2 text-lg font-medium rounded-md hover:bg-[#fb5f5f] transition"
>
  <FiPlus size={20} /> Add User
</NavLink>
      </div>

      {/* Table */}
      {/* Table Section */}
      <div className="mt-6 overflow-x-auto bg-white">
        <table className="w-full border-collapse min-w-[600px]">
          <thead>
            <tr className="text-gray-700 bg-white">
              <th className="px-6 py-4 text-left">Username</th>
              <th className="px-6 py-4 text-left">Email</th>
              <th className="px-6 py-4 text-left">Role</th>
              <th className="px-6 py-4 text-left">Created At</th>
              <th className="px-6 py-4 text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredUsers.length > 0 ? (
              filteredUsers.map((user, index) => (
                <tr
                  key={user.user_id}
                  className={`${
                    index % 2 === 0 ? "bg-[#F5F5F5]" : "bg-white"
                  } hover:bg-gray-100 transition text-[#5E5E5E]`}
                >
                  <td className="px-6 py-4 border-b border-gray-200">{user.username}</td>
                  <td className="px-6 py-4 border-b border-gray-200">{user.email}</td>
                  <td className="px-6 py-4 border-b border-gray-200">{user.role}</td>
                  <td className="px-6 py-4 border-b border-gray-200">
                    {new Date(user.created_at).toLocaleDateString()}
                  </td>
                  <td className="flex justify-center gap-4 px-6 py-4 border-b border-gray-200">
                    <button className="text-blue-500 transition hover:text-blue-700">
                      <FiEye size={18}/>
                    </button>
                    <button className="text-green-500 hover:text-green-700">
                    <FiEdit size={18} />
                      </button> 
                    <button className="text-red-500 transition hover:text-red-700">
                      <FiTrash2 size={18} onClick={() => deleteUser(user)}/>
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" className="px-6 py-6 text-center text-gray-500">
                  No users found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
        {selectedUser && <UserDetails user={selectedUser} isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />}
      </div>
      <ToastContainer />

    </div>
  );
};

export default UserTable;
