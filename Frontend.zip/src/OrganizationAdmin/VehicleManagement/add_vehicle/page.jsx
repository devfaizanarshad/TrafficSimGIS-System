"use client";

import { useState, useEffect, useRef } from "react";
import { EyeIcon, EyeOffIcon } from "@heroicons/react/solid";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css"; // Import Toastify styles

export default function VehcileForm() {
  const sidebarRef = useRef(null);
  const buttonRef = useRef(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [vehicles, setvehicles] = useState([]);
  const [showModal, setShowModal] = useState(false);
 

  const [formData, setFormData] = useState({
    model: "",
    year: "",
    image: ""
  });

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const createVehicle = async () => {

      try {
        const response = await fetch("http://localhost:3000/api/admin/create-vehicle", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(formData),
        });
  
        if (response.ok) {
          toast.success("Vehicle registered successfully!", { position: "top-center", autoClose: 3000 });
        } else {
          toast.error("Failed to register Vehicle.", { position: "top-center", autoClose: 3000 });
        }


          setFormData({
            model: "",
            year: "",
            image: ""
          });
  
      } catch (error) {
        console.error("Error adding Vehicle:", error);
      }
  };

  const handleClickOutside = (event) => {
    if (
      sidebarRef.current &&
      !sidebarRef.current.contains(event.target) &&
      buttonRef.current &&
      !buttonRef.current.contains(event.target)
    ) {
      setIsSidebarOpen(false);
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData((prev) => ({ ...prev, image: file }));
    }
  };

  const handleFileDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) {
      setFormData((prev) => ({ ...prev, image: file }));
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <div className="flex items-center justify-center mt-6 bg-gray-100">
      <div className="w-full max-w-5xl p-12 overflow-y-auto bg-white rounded-lg shadow-lg">

        {/* Form Heading & Subheading */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-800">Vehicle Details</h2>
          <p className="text-gray-500">Fill in the details below to create an vehicle.</p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {renderInput("Model", "model", formData, setFormData, true)}
          {renderInput("Year", "year", formData, setFormData, true)}
        </div>



        {/* File Upload Section */}
        <div className="mt-6">
          <label className="block text-sm font-medium text-gray-700">Upload Image</label>
          <div
            className="p-6 mt-2 text-center text-gray-500 border-2 border-gray-300 border-dashed cursor-pointer"
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleFileDrop}
          >
            {formData.image ? (
              <div className="flex flex-col items-center">
                <img
                  src={URL.createObjectURL(formData.image)}
                  alt="Uploaded"
                  className="object-contain mb-2 max-h-40"
                />
                <button
                  type="button"
                  className="text-sm text-red-500 underline"
                  onClick={() => setFormData((prev) => ({ ...prev, image: null }))}
                >
                  Remove Image
                </button>
              </div>
            ) : (
              <>
                <p>Drag and drop an image here, or click to select a file</p>
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  id="fileUpload"
                  onChange={handleFileChange}
                />
                <label
                  htmlFor="fileUpload"
                  className="text-blue-500 underline cursor-pointer"
                >
                  Browse Files
                </label>
              </>
            )}
          </div>
        </div>

        {/* Buttons */}
        <div className="flex justify-end mt-6 mb-10 space-x-4">
          <button type="button" className="px-4 py-2 bg-gray-300 rounded-lg" onClick={() => console.log("Cancelled")}>
            Cancel
          </button>
          <button type="button" className="px-4 py-2 text-white bg-red-500 rounded-lg"   onClick={createVehicle} >
            Save
          </button>
        </div>
      </div>

      <ToastContainer />

    </div>

  );
  
}

// Updated renderInput function to support custom classNames
function renderInput(label, name, formData, setFormData, required = false, type = "text", additionalClass = "") {
  return (
    <div className="flex flex-col">
      <label className="pb-1 font-medium text-gray-700">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <input
        type={type}
        name={name}
        value={formData[name]}
        onChange={(e) => setFormData((prev) => ({ ...prev, [name]: e.target.value }))}
        className={`p-2 border border-gray-300 rounded-lg ${additionalClass}`}
      />
    </div>
  );
}
