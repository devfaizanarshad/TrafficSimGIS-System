"use client";

import { useState, useEffect, useRef } from "react";
import { EyeIcon, EyeOffIcon } from "@heroicons/react/solid";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css"; // Import Toastify styles

export default function ApplianceForm() {
  const sidebarRef = useRef(null);
  const buttonRef = useRef(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [branches, setBranches] = useState([]);
  const [showModal, setShowModal] = useState(false);
 

  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    role: "Employee",
    first_name: "",
    last_name: "",
    address: "",
    city: "",
    phone: "",
    branch_name: "",
    image: ""
  });

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    const fetchBranches = async () => {
      try {
        const response = await fetch("http://localhost:3000/api/admin/list-branches");
        const data = await response.json();
        console.log(data);
        
        setBranches(data.branches || []);
      } catch (error) {
        console.error("Error fetching branches:", error);
      }
    };
    fetchBranches();
  }, []);

  const createUser = async () => {

      try {
        const response = await fetch("http://localhost:3000/api/admin/create-user", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(formData),
        });
  
        if (response.ok) {
          toast.success("User registered successfully!", { position: "top-center", autoClose: 3000 });
        } else {
          toast.error("Failed to register User.", { position: "top-center", autoClose: 3000 });
        }


          setFormData({
            username: "",
            email: "",
            password: "",
            role: "Employee",
            first_name: "",
            last_name: "",
            address: "",
            city: "",
            phone: "",
            branch_name: "",
            image: "",
          });
  
      } catch (error) {
        console.error("Error adding user:", error);
      }
  };
  

  const filteredBranches = branches.filter((branch) =>
    branch.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleClickOutside = (event) => {
    if (
      sidebarRef.current &&
      !sidebarRef.current.contains(event.target) &&
      buttonRef.current &&
      !buttonRef.current.contains(event.target)
    ) {
      setIsSidebarOpen(false);
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData((prev) => ({ ...prev, image: file }));
    }
  };

  const handleFileDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) {
      setFormData((prev) => ({ ...prev, image: file }));
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <div className="flex items-center justify-center bg-gray-100">
      <div className="w-full max-w-5xl p-12 overflow-y-auto bg-white rounded-lg shadow-lg">

        {/* Form Heading & Subheading */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-800">User Registration</h2>
          <p className="text-gray-500">Fill in the details below to create an account.</p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {renderInput("Username", "username", formData, setFormData, true)}
          {renderInput("Email", "email", formData, setFormData, true)}

          <div className="relative">
            {renderInput(
              "Password",
              "password",
              formData,
              setFormData,
              true,
              showPassword ? "text" : "password",
              "pr-12"
            )}
            <button
              type="button"
              className="absolute text-gray-500 transform -translate-y-1/2 right-4 top-1/2"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? <EyeOffIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
            </button>
          </div>

          {renderInput("First Name", "first_name", formData, setFormData, true)}
          {renderInput("Last Name", "last_name", formData, setFormData, true)}
          {renderInput("Address", "address", formData, setFormData)}
          {renderInput("City", "city", formData, setFormData)}
          {renderInput("Phone", "phone", formData, setFormData)}


          {/* Role Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700">Role</label>
            <select
              name="role"
              value={formData.role}
              onChange={handleChange}
              className="w-full p-2 mt-1 border border-gray-300 rounded-md"
            >
              <option value="Employee">Employee</option>
              <option value="Admin">Admin</option>
              <option value="Manager">Manager</option>
            </select>
          </div>

            {/* Branch Dropdown */}


          <div className="relative">
      <label className="block text-sm font-medium text-gray-700">Branch</label>
      <div
        className="w-full p-2 mt-1 bg-white border border-gray-300 rounded-md cursor-pointer"
        onClick={() => setIsOpen(!isOpen)}
      >
        {formData.branch_name || "Select a branch"}
      </div>

      {isOpen && (
        <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-md">
          <input
            type="text"
            placeholder="Search branch..."
            className="w-full p-2 border-b border-gray-200 outline-none"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <ul className="overflow-y-auto max-h-32">
            {filteredBranches.length > 0 ? (
              filteredBranches.map((branch) => (
                <li
                  key={branch.id}
                  className="p-2 cursor-pointer hover:bg-gray-100"
                  onClick={() => {
                    handleChange({ target: { name: "branch_name", value: branch.name } });
                    setIsOpen(false);
                  }}
                >
                  {branch.name}
                </li>
              ))
            ) : (
              <li className="p-2 text-gray-500">No results found</li>
            )}
          </ul>
        </div>
      )}
    </div>
        </div>



        {/* File Upload Section */}
        <div className="mt-6">
          <label className="block text-sm font-medium text-gray-700">Upload Image</label>
          <div
            className="p-6 mt-2 text-center text-gray-500 border-2 border-gray-300 border-dashed cursor-pointer"
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleFileDrop}
          >
            {formData.image ? (
              <div className="flex flex-col items-center">
                <img
                  src={URL.createObjectURL(formData.image)}
                  alt="Uploaded"
                  className="object-contain mb-2 max-h-40"
                />
                <button
                  type="button"
                  className="text-sm text-red-500 underline"
                  onClick={() => setFormData((prev) => ({ ...prev, image: null }))}
                >
                  Remove Image
                </button>
              </div>
            ) : (
              <>
                <p>Drag and drop an image here, or click to select a file</p>
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  id="fileUpload"
                  onChange={handleFileChange}
                />
                <label
                  htmlFor="fileUpload"
                  className="text-blue-500 underline cursor-pointer"
                >
                  Browse Files
                </label>
              </>
            )}
          </div>
        </div>

        {/* Buttons */}
        <div className="flex justify-end mt-6 mb-10 space-x-4">
          <button type="button" className="px-4 py-2 bg-gray-300 rounded-lg" onClick={() => console.log("Cancelled")}>
            Cancel
          </button>
          <button type="button" className="px-4 py-2 text-white bg-red-500 rounded-lg"   onClick={createUser} >
            Save
          </button>
        </div>
      </div>

      <ToastContainer />

    </div>

  );
  
}

// Updated renderInput function to support custom classNames
function renderInput(label, name, formData, setFormData, required = false, type = "text", additionalClass = "") {
  return (
    <div className="flex flex-col">
      <label className="pb-1 font-medium text-gray-700">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <input
        type={type}
        name={name}
        value={formData[name]}
        onChange={(e) => setFormData((prev) => ({ ...prev, [name]: e.target.value }))}
        className={`p-2 border border-gray-300 rounded-lg ${additionalClass}`}
      />
    </div>
  );
}
