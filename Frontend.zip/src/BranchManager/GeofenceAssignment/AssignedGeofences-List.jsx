import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { FiSearch, FiEye, FiTrash2 } from "react-icons/fi";
import Select from "react-select";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const AssignedGeofenceList = () => {
  const [assignedGeofences, setAssignedGeofences] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();


  const [employees, setEmployees] = useState([]);
  const [geofences, setGeofences] = useState([]);

  const [filters, setFilters] = useState({
    employeeId: null,
    geoId: null,
    accessType: "",
  });

  const managerId = 1;

  useEffect(() => {
    fetchDropdownData();
  }, []);

  const fetchDropdownData = async () => {
    try {
      const empRes = await fetch(`http://localhost:3000/api/manager/${managerId}/employees`);
      const empData = await empRes.json();
      setEmployees(empData.employees || []);

      const geoRes = await fetch("http://localhost:3000/api/admin/list-geofences");
      const geoData = await geoRes.json();
      setGeofences(geoData.geofences || []);
    } catch (err) {
      console.error(err);
      toast.error("Error loading dropdown data.");
    }
  };

  useEffect(() => {
    fetchAssignedGeofences();
  }, [filters]);

  const fetchAssignedGeofences = async () => {
    setLoading(true);

    let query = "";
    if (filters.employeeId) query += `employeeId=${filters.employeeId}&`;
    if (filters.geoId) query += `geoId=${filters.geoId}&`;
    if (filters.accessType) query += `accessType=${filters.accessType}`;

    try {
      const res = await fetch(`http://localhost:3000/api/manager/assigned-geofences?${query}`);
      const data = await res.json();
      setAssignedGeofences(data.geofences || []);
      setLoading(false);
    } catch (err) {
      console.error(err);
      toast.error("Failed to fetch assigned geofences.");
      setLoading(false);
    }
  };

  const handleDeactivate = (geoId) => {
    toast.info(
      <div>
        <p className="text-lg font-semibold">Confirm Action</p>
        <p className="text-sm text-gray-600">Deactivate this geofence assignment?</p>
        <div className="flex justify-end mt-3 space-x-3">
          <button onClick={toast.dismiss} className="px-4 py-2 bg-gray-300 rounded-lg">
            Cancel
          </button>
          <button
            className="px-4 py-2 text-white bg-red-500 rounded-lg"
            onClick={async () => {
              toast.dismiss();
              try {
                const res = await fetch(
                  `http://localhost:3000/api/admin/deactivate-geofence/${geoId}`,
                  { method: "PATCH" }
                );

                if (res.ok) {
                  toast.success("Geofence deactivated successfully!");
                  fetchAssignedGeofences();
                } else {
                  toast.error("Failed to deactivate.");
                }
              } catch (err) {
                toast.error("Error occurred while deactivating.");
              }
            }}
          >
            Confirm
          </button>
        </div>
      </div>,
      { autoClose: false }
    );
  };

  const selectStyles = {
    control: (styles) => ({
      ...styles,
      borderRadius: "9999px",
      padding: "2px",
      borderColor: "#E5E7EB",
      boxShadow: "none",
      ":hover": { borderColor: "#FF8A8A" },
    }),
    option: (styles, { isSelected }) => ({
      ...styles,
      backgroundColor: isSelected ? "#FF8A8A" : "#fff",
      color: isSelected ? "#fff" : "#333",
    }),
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return "-";
    const dateObj = new Date(dateStr);
    return dateObj.toLocaleDateString("en-GB"); // dd/mm/yyyy
  };

  const handleViewViolations = (employee_id, geofence_name) => {
    navigate(`/branchmanager/view-voilations?employeeId=${employee_id}&geoname=${geofence_name}`);
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-md">
      {/* Filters */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div className="w-full sm:w-[250px]">
          <Select
            options={employees.map((e) => ({
              value: e.employee_id,
              label: `${e.first_name} ${e.last_name}`,
            }))}
            onChange={(selected) =>
              setFilters({ ...filters, employeeId: selected ? selected.value : null })
            }
            isClearable
            placeholder="Filter by Employee"
            styles={selectStyles}
          />
        </div>

        <div className="w-full sm:w-[250px]">
          <Select
            options={geofences.map((g) => ({
              value: g.geo_id,
              label: g.name,
            }))}
            onChange={(selected) =>
              setFilters({ ...filters, geoId: selected ? selected.value : null })
            }
            isClearable
            placeholder="Filter by Geofence"
            styles={selectStyles}
          />
        </div>

        <div className="w-full sm:w-[250px]">
          <Select
            options={[
              { value: "Authorized", label: "Authorized" },
              { value: "Restricted", label: "Restricted" },
            ]}
            onChange={(selected) =>
              setFilters({ ...filters, accessType: selected ? selected.value : "" })
            }
            isClearable
            placeholder="Access Type"
            styles={selectStyles}
          />
        </div>
      </div>

      {/* Assigned Geofences Table */}
      {loading ? (
        <p className="p-10 text-center">Loading...</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full border-collapse min-w-[600px]">
            <thead>
              <tr className="text-gray-700 bg-white">
                <th className="px-6 py-4 text-left">Employee</th>
                <th className="px-6 py-4 text-left">Geofence</th>
                <th className="px-6 py-4 text-left">Access</th>
                <th className="px-6 py-4 text-left">Start / End Date</th>
                <th className="px-6 py-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {assignedGeofences.length > 0 ? (
                assignedGeofences.map((g, idx) => (
                  <tr
                    key={idx}
                    className={`${
                      idx % 2 === 0 ? "bg-[#F5F5F5]" : "bg-white"
                    } hover:bg-gray-100 transition text-[#5E5E5E]`}
                  >
                    <td className="px-6 py-4 border-b border-gray-200">{g.employee_id || "N/A"}</td>
                    <td className="px-6 py-4 border-b border-gray-200">{g.geofence_name}</td>
                    <td className="px-6 py-4 border-b border-gray-200">{g.access_type}</td>
                    <td className="px-6 py-4 border-b border-gray-200">
                      {formatDate(g.start_date)} - {formatDate(g.end_date)}
                    </td>
                    <td className="flex justify-center gap-4 px-6 py-4 border-b border-gray-200">
                      <button
                        className="text-blue-500 hover:text-blue-700"
                        onClick={() => handleViewViolations(g.employee_id, g.geofence_name)}
                        >
                        <FiEye size={18} />
                      </button>
                      <button
                        className="text-red-500 hover:text-red-700"
                        onClick={() => handleDeactivate(g.geo_id)}
                      >
                        <FiTrash2 size={18} />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="5" className="px-6 py-6 text-center text-gray-500">
                    No assigned geofences found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      <ToastContainer />
    </div>
  );
};

export default AssignedGeofenceList;
