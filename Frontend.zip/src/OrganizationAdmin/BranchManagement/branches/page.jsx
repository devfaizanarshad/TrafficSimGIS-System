import React, { useEffect, useState } from "react";
import axios from "axios";
import { NavLink } from "react-router-dom";
import { FiPlus, FiEdit,FiSearch, FiEye, FiTrash2 } from "react-icons/fi";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Modal from "react-modal";

const BranchTable = () => {
const [Branchs, setBranch] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("");
  const [selectedBranch, setSelectedBranch] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    axios
      .get("http://localhost:3000/api/admin/list-branches")
      .then((response) => {
        console.log(response.data.branches);
        
        setBranch(response.data.branches);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching branch:", error);
        setError("Failed to fetch data.");
        setLoading(false);
      });
  }, []);

   // Delete user function
   const deleteBranch = async (Branch) => {
    toast.info(
      <div>
        <p className="text-lg font-semibold">Are you sure?</p>
        <p className="text-sm text-gray-600">You are about to delete <b>{Branch.name}</b>.</p>
        <div className="flex justify-end mt-3 space-x-3">
          <button className="px-4 py-2 bg-gray-300 rounded-lg" onClick={toast.dismiss}>Cancel</button>
          <button
            className="px-4 py-2 text-white bg-red-500 rounded-lg"
            onClick={async () => {
              toast.dismiss();
              try {
                const response = await fetch(`http://localhost:3000/api/admin/deactivate-branch/${Branch.branch_id}`, {
                  method: "PATCH",
                });

                if (response.ok) {
                  setBranch(Branchs.filter((b) => b.branch_id !== b.branc_id));
                  toast.success("Branch deleted successfully!", { autoClose: 2000 });
                } else {
                  toast.error("Failed to delete Branch.");
                }
              } catch (error) {
                console.error("Error deleting Branch:", error);
                toast.error("An error occurred while deleting the Branch.");
              }
            }}
          >
            Confirm
          </button>
        </div>
      </div>,
      { autoClose: false, closeOnClick: false, draggable: false }
    );
  };

  const filteredBranch = Branchs.filter(
    (branch) =>
      branch.name.toLowerCase().includes(search.toLowerCase()));

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div className="min-h-screen p-6 bg-white">
      <div className="flex flex-wrap items-center gap-3 mb-4">
        {/* Search Bar */}
        <div className="relative flex items-center w-full max-w-md">
          <FiSearch className="absolute text-gray-500 left-3" />
          <input
            type="text"
            placeholder="Search users..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-6 py-2 border border-gray-300 bg-white rounded-full shadow-sm focus:outline-none focus:ring-2 focus:ring-[#FF8A8A]"
          />
        </div>

        {/* Filter Dropdown */}
        <div className="flex items-center">
          <span className="mr-2 text-[#6B7280]">Filter by</span>
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="px-6 py-2 border border-gray-300 bg-white rounded-full text-[#6B7280] focus:outline-none focus:ring-2"
          >
            <option value="">All Roles</option>
            <option value="Employee">Employee</option>
            <option value="Manager">Manager</option>
            <option value="Admin">Admin</option>
          </select>
        </div>

{/* Add Branch Button */}
<NavLink
  to="/admin/create-branch"
  className="flex items-center ml-15 gap-3 bg-[#FF8A8A] text-white px-6 py-2 text-lg font-medium rounded-md hover:bg-[#fb5f5f] transition"
>
  <FiPlus size={20} /> Add Branch
</NavLink>
      </div>

      {/* Table */}
      {/* Table Section */}
      <div className="mt-6 overflow-x-auto bg-white">
        <table className="w-full border-collapse min-w-[600px]">
          <thead>
            <tr className="text-gray-700 bg-white">
              <th className="px-6 py-4 text-left">Name</th>
              <th className="px-6 py-4 text-left">Address</th>
              <th className="px-6 py-4 text-left">Phone</th>
              <th className="px-6 py-4 text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredBranch.length > 0 ? (
              filteredBranch.map((branch, index) => (
                <tr
                  key={branch.branc_id}
                  className={`${
                    index % 2 === 0 ? "bg-[#F5F5F5]" : "bg-white"
                  } hover:bg-gray-100 transition text-[#5E5E5E]`}
                >
                  <td className="px-6 py-4 border-b border-gray-200">{branch.name}</td>
                  <td className="px-6 py-4 border-b border-gray-200">{branch.address}</td>
                  <td className="px-6 py-4 border-b border-gray-200">{branch.phoneno}</td>
                  <td className="flex justify-center gap-4 px-6 py-4 border-b border-gray-200">
                    <button className="text-blue-500 transition hover:text-blue-700">
                      <FiEye size={18}/>
                    </button>                   
                    <button className="text-green-500 hover:text-green-700">
                    <FiEdit size={18} />
                      </button>  
                    <button className="text-red-500 transition hover:text-red-700">
                      <FiTrash2 size={18} onClick={() => deleteBranch(branch)}/>
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" className="px-6 py-6 text-center text-gray-500">
                  No Branch found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
     <ToastContainer />
      
    </div>
  );
};
export default BranchTable;
