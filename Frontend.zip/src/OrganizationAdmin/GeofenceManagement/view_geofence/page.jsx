"use client";

import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom"; // React Router hooks
import {
  MapContainer,
  TileLayer,
  Polygon,
  Popup
} from "react-leaflet";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const ViewGeofencePage = () => {
  const { geofenceName } = useParams(); // Get geofence name from the URL
  const navigate = useNavigate();
  const [geofence, setGeofence] = useState(null);
  const [loading, setLoading] = useState(true);

  // Fetch geofence by name on mount
  useEffect(() => {
    const fetchSingleGeofence = async () => {
      try {
        const response = await fetch(`http://localhost:3000/api/admin/single-geofence/${encodeURIComponent(geofenceName)}`);
        const data = await response.json();

        if (response.ok) {
          setGeofence(data.geofence);
          toast.success("Geofence loaded!");
        } else {
          toast.error("Failed to load geofence.");
        }
      } catch (error) {
        console.error("Error fetching single geofence:", error);
        toast.error("Server error fetching geofence.");
      } finally {
        setLoading(false);
      }
    };

    fetchSingleGeofence();
  }, [geofenceName]);

  const handleBack = () => {
    navigate("/admin/geofence-management"); // Go back to the geofence list
  };

  return (
    <div className="flex flex-col items-center justify-center p-8 bg-gray-100">
      <div className="w-full max-w-5xl p-8 bg-white rounded-lg shadow-lg">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-800">View Geofence</h2>
          <button
            onClick={handleBack}
            className="px-4 py-2 transition bg-gray-300 rounded-md hover:bg-gray-400"
          >
            Back
          </button>
        </div>

        {/* Loading or Error */}
        {loading ? (
          <p>Loading...</p>
        ) : !geofence ? (
          <p className="text-red-500">Geofence not found.</p>
        ) : (
          <>
            {/* Geofence Info */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-gray-800">{geofence.name}</h3>
              <p className="mb-2 text-sm text-gray-600">
                Created at: {new Date(geofence.created_at).toLocaleString()}
              </p>
            </div>

            {/* Map Section */}
            <div className="h-[400px] mb-6">
              <MapContainer
                center={[
                  geofence.boundary[0].latitude,
                  geofence.boundary[0].longitude
                ]}
                zoom={16}
                className="w-full h-full rounded-lg"
              >
                <TileLayer
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  attribution="© OpenStreetMap"
                />

                <Polygon
                  positions={geofence.boundary.map((point) => [
                    point.latitude,
                    point.longitude
                  ])}
                  pathOptions={{ color: "#1E90FF" }}
                >
                  <Popup>{geofence.name}</Popup>
                </Polygon>
              </MapContainer>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end space-x-4">
              <button
                onClick={handleBack}
                className="px-4 py-2 transition bg-gray-300 rounded-md hover:bg-gray-400"
              >
                Cancel
              </button>
              <button
                onClick={() => navigate(`/admin/edit-geofence/${geofence.name}`)}
                className="bg-[#FF8A8A] text-white px-6 py-2 rounded-md hover:bg-[#fb5f5f] transition"
              >
                Edit Geofence
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default ViewGeofencePage;
