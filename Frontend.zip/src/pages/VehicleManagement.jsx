import React from "react";

const VehicleManagement = () => {
  return (
    <div className="p-6 bg-white rounded-lg shadow">
      <h2 className="text-xl font-bold">VehicleManagement</h2>
      <p className="mt-2 text-gray-600">This is the main VehicleManagement page.</p>
    </div>
  );
};

export default VehicleManagement;
