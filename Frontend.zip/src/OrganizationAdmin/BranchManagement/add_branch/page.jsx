"use client";

import { useState, useEffect, useRef } from "react";
import { EyeIcon, EyeOffIcon } from "@heroicons/react/solid";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css"; // Import Toastify styles

export default function BranchForm() {
  const sidebarRef = useRef(null);
  const buttonRef = useRef(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
 

  const [formData, setFormData] = useState({
    name: "",
    addresw: "",
    phone: ""
  });

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);


  const createBranch = async () => {

      try {
        const response = await fetch("http://localhost:3000/api/admin/create-branch", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(formData),
        });
  
        if (response.ok) {
          toast.success("Branch registered successfully!", { position: "top-center", autoClose: 3000 });
        } else {
          toast.error("Failed to register Branch.", { position: "top-center", autoClose: 3000 });
        }


          setFormData({
            name: "",
            addresw: "",
            phone: ""
          });
  
      } catch (error) {
        console.error("Error adding Branch:", error);
      }
  };

  const handleClickOutside = (event) => {
    if (
      sidebarRef.current &&
      !sidebarRef.current.contains(event.target) &&
      buttonRef.current &&
      !buttonRef.current.contains(event.target)
    ) {
      setIsSidebarOpen(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <div className="flex items-center justify-center bg-gray-100">
      <div className="w-full max-w-5xl p-12 overflow-y-auto bg-white rounded-lg shadow-lg">

        {/* Form Heading & Subheading */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-800">Branch Details</h2>
          <p className="text-gray-500">Fill in the details below to create a new barnch.</p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {renderInput("Name", "name", formData, setFormData, true)}
          {renderInput("Address", "address", formData, setFormData, true)}
          {renderInput("Phone", "phone", formData, setFormData)}
        </div>


        {/* Buttons */}
        <div className="flex justify-end mt-6 mb-10 space-x-4">
          <button type="button" className="px-4 py-2 bg-gray-300 rounded-lg" onClick={() => console.log("Cancelled")}>
            Cancel
          </button>
          <button type="button" className="px-4 py-2 text-white bg-red-500 rounded-lg"   onClick={createBranch} >
            Save
          </button>
        </div>
      </div>

      <ToastContainer />

    </div>

  );
  
}

// Updated renderInput function to support custom classNames
function renderInput(label, name, formData, setFormData, required = false, type = "text", additionalClass = "") {
  return (
    <div className="flex flex-col">
      <label className="pb-1 font-medium text-gray-700">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <input
        type={type}
        name={name}
        value={formData[name]}
        onChange={(e) => setFormData((prev) => ({ ...prev, [name]: e.target.value }))}
        className={`p-2 border border-gray-300 rounded-lg ${additionalClass}`}
      />
    </div>
  );
}
