import React from "react";

const GeofenceManagement = () => {
  return (
    <div className="p-6 bg-white rounded-lg shadow">
      <h2 className="text-xl font-bold">GeofenceManagement</h2>
      <p className="mt-2 text-gray-600">This is the main GeofenceManagement page.</p>
    </div>
  );
};

export default GeofenceManagement;
