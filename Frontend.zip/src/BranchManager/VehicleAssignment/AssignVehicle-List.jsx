import React, { useEffect, useState } from "react";
import { FiSearch, FiEye } from "react-icons/fi";
import Select from "react-select";
import toast from "react-hot-toast";

const AssignedVehicles = () => {
  const [assignedVehicles, setAssignedVehicles] = useState([]);
  const [filteredVehicles, setFilteredVehicles] = useState([]);
  const [loading, setLoading] = useState(true);

  const [employees, setEmployees] = useState([]);
  const [vehicles, setVehicles] = useState([]);

  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [selectedVehicle, setSelectedVehicle] = useState(null);

  const managerId = 1; // 🔥 Hardcoded, later replace with logged-in manager!

  // Fetch assigned vehicles
  useEffect(() => {
    const fetchAssignedVehicles = async () => {
      try {
        const res = await fetch("http://localhost:3000/api/manager/assigned-vehicles");
        const data = await res.json();

        setAssignedVehicles(data.vehicles || []);
        setFilteredVehicles(data.vehicles || []);
        setLoading(false);
      } catch (error) {
        toast.error("Failed to load assigned vehicles.");
        setLoading(false);
      }
    };

    fetchAssignedVehicles();
  }, []);

  // Fetch employees list
  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const res = await fetch(`http://localhost:3000/api/manager/${managerId}/employees`);
        const data = await res.json();

        setEmployees(data.employees || []);
      } catch (error) {
        toast.error("Failed to load employees.");
      }
    };

    fetchEmployees();
  }, []);

  // Fetch all vehicles list
  useEffect(() => {
    const fetchVehicles = async () => {
      try {
        const res = await fetch(`http://localhost:3000/api/admin/list-vehicles`);
        const data = await res.json();

        setVehicles(data.vehicles || []);
      } catch (error) {
        toast.error("Failed to load vehicles.");
      }
    };

    fetchVehicles();
  }, []);

  // Handle Filters
  useEffect(() => {
    let filtered = [...assignedVehicles];

    if (selectedEmployee) {
      filtered = filtered.filter(
        (v) => v.employee_id === selectedEmployee.value
      );
    }

    if (selectedVehicle) {
      filtered = filtered.filter(
        (v) => v.vehicle_id === selectedVehicle.value
      );
    }

    setFilteredVehicles(filtered);
  }, [selectedEmployee, selectedVehicle, assignedVehicles]);

  const getEmployeeName = (employee_id) => {
    const emp = employees.find((e) => e.employee_id === employee_id);
    return emp ? `${emp.first_name} ${emp.last_name}` : `Employee ID ${employee_id}`;
  };

  console.log(vehicles);
  

  const getVehicleModel = (vehicle_id) => {
    const vehicle = vehicles.find((v) => v.vehicle_id === vehicle_id);
    return vehicle ? `${vehicle.model} (${vehicle.year})` : `Vehicle ID ${vehicle_id}`;
  };

  const employeeOptions = employees.map((emp) => ({
    value: emp.employee_id,
    label: `${emp.first_name} ${emp.last_name}`,
  }));

  const vehicleOptions = vehicles.map((v) => ({
    value: v.vehicle_id,
    label: `${v.model} (${v.year})`,
  }));

  if (loading) return <p className="p-10 text-center">Loading...</p>;

  return (
    <div className="p-6 bg-white rounded-lg shadow-md">
      {/* Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        {/* Filter by Employee */}
        <div className="w-full md:w-1/3">
          <label className="block mb-1 text-sm font-semibold text-gray-700">
            Filter by Employee
          </label>
          <Select
            options={employeeOptions}
            value={selectedEmployee}
            onChange={setSelectedEmployee}
            placeholder="Select employee..."
            isClearable
          />
        </div>

        {/* Filter by Vehicle */}
        <div className="w-full md:w-1/3">
          <label className="block mb-1 text-sm font-semibold text-gray-700">
            Filter by Vehicle
          </label>
          <Select
            options={vehicleOptions}
            value={selectedVehicle}
            onChange={setSelectedVehicle}
            placeholder="Select vehicle..."
            isClearable
          />
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full border-collapse min-w-[600px]">
          <thead>
            <tr className="text-gray-700 bg-white">
              <th className="px-6 py-4 text-left">Employee Name</th>
              <th className="px-6 py-4 text-left">Vehicle Model</th>
              <th className="px-6 py-4 text-left">Assign Date</th>
              <th className="px-6 py-4 text-left">Return Date</th>
            </tr>
          </thead>
          <tbody>
            {filteredVehicles.length > 0 ? (
              filteredVehicles.map((v, idx) => (
                <tr
                  key={`${v.vehicle_id}-${v.employee_id}`}
                  className={`${
                    idx % 2 === 0 ? "bg-[#F5F5F5]" : "bg-white"
                  } hover:bg-gray-100 transition text-[#5E5E5E]`}
                >
                  <td className="px-6 py-4 border-b border-gray-200">
                    {getEmployeeName(v.employee_id)}
                  </td>
                  <td className="px-6 py-4 border-b border-gray-200">
                    {getVehicleModel(v.vehicle_id)}
                  </td>
                  <td className="px-6 py-4 border-b border-gray-200">
                    {new Date(v.assign_date).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 border-b border-gray-200">
                    {v.return_date
                      ? new Date(v.return_date).toLocaleDateString()
                      : "Not Returned"}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4" className="px-6 py-6 text-center text-gray-500">
                  No vehicle assignments found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AssignedVehicles;
