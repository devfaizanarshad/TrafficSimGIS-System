import React, { useEffect, useState } from "react";
import { FiSearch, FiEye, FiEdit, FiTrash2, FiPlus } from "react-icons/fi";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { NavLink } from "react-router-dom";

const ListGeofences = () => {
  const [geofences, setGeofences] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    fetchGeofences();
  }, []);

  const fetchGeofences = async () => {
    try {
      const response = await fetch("http://localhost:3000/api/admin/list-geofences");
      const data = await response.json();
      setGeofences(data.geofences);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching geofences:", error);
      toast.error("Failed to fetch geofences");
      setLoading(false);
    }
  };

  const deleteGeofence = async (geo_id, name) => {
    toast.info(
      <div>
        <p className="text-lg font-semibold">Are you sure?</p>
        <p className="text-sm text-gray-600">You are about to delete <b>{name}</b>.</p>
        <div className="flex justify-end mt-3 space-x-3">
          <button
            className="px-4 py-2 bg-gray-300 rounded-lg"
            onClick={toast.dismiss}
          >
            Cancel
          </button>
          <button
            className="px-4 py-2 text-white bg-red-500 rounded-lg"
            onClick={async () => {
              toast.dismiss();
              try {
                const res = await fetch(`http://localhost:3000/api/admin/deactivate-geofence/${geo_id}`, {
                  method: "PATCH",
                });

                if (res.ok) {
                  toast.success("Geofence deleted successfully!");
                  setGeofences(geofences.filter((g) => g.geo_id !== geo_id));
                } else {
                  toast.error("Failed to delete geofence.");
                }
              } catch (error) {
                console.error("Error deleting geofence:", error);
                toast.error("An error occurred while deleting the geofence.");
              }
            }}
          >
            Confirm
          </button>
        </div>
      </div>,
      { autoClose: false, closeOnClick: false, draggable: false }
    );
  };

  const filteredGeofences = geofences.filter((g) =>
    g.name.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) return <p className="p-10">Loading...</p>;

  return (
    <div className="p-6 bg-white rounded-lg shadow-md">
      {/* Top Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        {/* Search */}
        <div className="relative flex items-center w-full max-w-md">
          <FiSearch className="absolute text-gray-500 left-3" />
          <input
            type="text"
            placeholder="Search geofences..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-6 py-2 border border-gray-300 bg-white rounded-full shadow-sm focus:outline-none focus:ring-2 focus:ring-[#FF8A8A]"
          />
        </div>

        {/* Add Button */}
        <NavLink
          to="/admin/create-geofence"
          className="flex items-center gap-2 px-6 py-2 text-white bg-[#FF8A8A] rounded-md hover:bg-[#fb5f5f] transition"
        >
          <FiPlus size={18} /> Add Geofence
        </NavLink>
      </div>

      {/* Geofences Table */}
      <div className="overflow-x-auto">
        <table className="w-full border-collapse min-w-[600px]">
          <thead>
            <tr className="text-gray-700 bg-white">
              <th className="px-6 py-4 text-left">Name</th>
              <th className="px-6 py-4 text-left">Points</th>
              <th className="px-6 py-4 text-left">Created At</th>
              <th className="px-6 py-4 text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredGeofences.length > 0 ? (
              filteredGeofences.map((geo, idx) => (
                <tr
                  key={geo.geo_id}
                  className={`${
                    idx % 2 === 0 ? "bg-[#F5F5F5]" : "bg-white"
                  } hover:bg-gray-100 transition text-[#5E5E5E]`}
                >
                  <td className="px-6 py-4 border-b border-gray-200">{geo.name}</td>
                  <td className="px-6 py-4 border-b border-gray-200">
                    {geo.boundary.length} Points
                  </td>
                  <td className="px-6 py-4 border-b border-gray-200">
                    {new Date(geo.created_at).toLocaleDateString()}
                  </td>
                  <td className="flex justify-center gap-4 px-6 py-4 border-b border-gray-200">
                  <NavLink
  to={`/admin/view-geofence/${encodeURIComponent(geo.name)}`}
  className="text-blue-500 hover:text-blue-700"
>
  <FiEye size={18} />
</NavLink>

                    <NavLink
                      to={`/admin/edit-geofence/${geo.geo_id}`}
                      className="text-green-500 hover:text-green-700"
                    >
                      <FiEdit size={18} />
                    </NavLink>
                    <button
  className="text-red-500 transition hover:text-red-700"
  onClick={() => deleteGeofence(geo.geo_id, geo.name)} // 🔥 Move it here
>
  <FiTrash2 size={18} />
</button>

                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4" className="px-6 py-6 text-center text-gray-500">
                  No geofences found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <ToastContainer />
    </div>
  );
};

export default ListGeofences;   /// bro nothing is happening when i click on trash icon