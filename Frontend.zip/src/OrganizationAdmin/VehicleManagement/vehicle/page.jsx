import React, { useEffect, useState } from "react";
import axios from "axios";
import { NavLink } from "react-router-dom";
import { FiPlus, FiEdit,FiSearch, FiEye, FiTrash2 } from "react-icons/fi";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Modal from "react-modal";

Modal.setAppElement("#root");

const VehicleTable = () => {
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("");
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    axios
      .get("http://localhost:3000/api/admin/list-vehicles")
      .then((response) => {
        if (response.data && Array.isArray(response.data.vehicles)) {
          setVehicles(response.data.vehicles);
        } else {
          setError("Invalid response format.");
        }
        setLoading(false);
      })
      .catch(() => {
        setError("Failed to fetch data.");
        setLoading(false);
      });
  }, []);

  const deleteVehicle = async (vehicle) => {
    toast.info(
      <div>
        <p className="text-lg font-semibold">Are you sure?</p>
        <p className="text-sm text-gray-600">You are about to delete <b>{vehicle.model}</b>.</p>
        <div className="flex justify-end mt-3 space-x-3">
          <button className="px-4 py-2 bg-gray-300 rounded-lg" onClick={toast.dismiss}>Cancel</button>
          <button
            className="px-4 py-2 text-white bg-red-500 rounded-lg"
            onClick={async () => {
              toast.dismiss();
              try {
                const response = await fetch(`http://localhost:3000/api/admin/deactivate-vehicle/${vehicle.vehicle_id}`, {
                  method: "PATCH",
                });

                if (response.ok) {
                  setVehicles(vehicles.filter((v) => v.vehicle_id !== vehicle.vehicle_id));
                  toast.success("Vehicle deleted successfully!");
                } else {
                  toast.error("Failed to delete vehicle.");
                }
              } catch {
                toast.error("An error occurred while deleting the vehicle.");
              }
            }}
          >
            Confirm
          </button>
        </div>
      </div>,
      { autoClose: false }
    );
  };

  const filteredVehicles = vehicles.filter(
    (vehicle) =>
      vehicle.model.toLowerCase().includes(search.toLowerCase()) &&
      (filter ? vehicle.is_available.toString() === filter : true)
  );

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div className="min-h-screen p-6 bg-white">
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <div className="relative flex items-center w-full max-w-md">
          <FiSearch className="absolute text-gray-500 left-3" />
          <input
            type="text"
            placeholder="Search Vehicles..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full py-2 pl-10 pr-6 bg-white border border-gray-300 rounded-full shadow-sm"
          />
        </div>

        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="px-6 py-2 text-gray-600 bg-white border border-gray-300 rounded-full"
        >
          <option value="">All</option>
          <option value="true">Available</option>
          <option value="false">Not Available</option>
        </select>

        <NavLink to="/admin/create-vehicle" className="flex items-center ml-15 gap-3 px-6 py-2 text-lg font-medium text-white bg-[#FF8A8A] rounded-md hover:bg-[#fb5f5f]">
          <FiPlus size={20} /> Add Vehicle
        </NavLink>
      </div>

      <div className="mt-6 overflow-x-auto bg-white">
        <table className="w-full border-collapse min-w-[600px]">
          <thead>
            <tr className="text-gray-700 bg-white">
              <th className="px-6 py-4 text-left">Model</th>
              <th className="px-6 py-4 text-left">Year</th>
              <th className="px-6 py-4 text-left">Availability</th>
              <th className="px-6 py-4 text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredVehicles.length > 0 ? (
              filteredVehicles.map((vehicle, index) => (
                <tr key={vehicle.vehicle_id} className={`${index % 2 === 0 ? "bg-[#F5F5F5]" : "bg-white"} hover:bg-gray-100 transition text-[#5E5E5E]`}>
                  <td className="px-6 py-4 border-b border-gray-200">{vehicle.model}</td>
                  <td className="px-6 py-4 border-b border-gray-200">{vehicle.year}</td>
                  <td className="px-6 py-4 border-b border-gray-200">{vehicle.is_available ? "Yes" : "No"}</td>
                  <td className="flex justify-center gap-4 px-6 py-4 border-b border-gray-200">
                    <button className="text-blue-500 transition hover:text-blue-700" onClick={() => { setSelectedVehicle(vehicle); setIsModalOpen(true); }}>
                      <FiEye size={18} />
                    </button>
                    <button className="text-green-500 hover:text-green-700">
                    <FiEdit size={18} />
                      </button> 
                    <button className="text-red-500 transition hover:text-red-700" onClick={() => deleteVehicle(vehicle)}>
                      <FiTrash2 size={18} />
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" className="px-6 py-6 text-center text-gray-500">No vehicles found.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <ToastContainer />
    </div>
  );
};

export default VehicleTable;